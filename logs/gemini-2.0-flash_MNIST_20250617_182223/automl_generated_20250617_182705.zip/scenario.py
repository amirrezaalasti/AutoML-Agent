from smac import Scenario
from ConfigSpace import ConfigurationSpace

def generate_scenario(cs: ConfigurationSpace) -> Scenario:
    """
    Generates a SMAC scenario configuration for hyperparameter optimization of an image dataset.

    Args:
        cs (ConfigurationSpace): The configuration space from which to sample configurations.

    Returns:
        Scenario: A SMAC Scenario object configured for the image dataset.
    """

    scenario = Scenario(
        configspace=cs,
        name="HyperparameterOptimization",
        output_directory="./logs/gemini-2.0-flash_MNIST_20250617_182223",
        deterministic=False,
        n_trials=10,
        min_budget=1,
        max_budget=10,
        n_workers=1
    )
    return scenario
