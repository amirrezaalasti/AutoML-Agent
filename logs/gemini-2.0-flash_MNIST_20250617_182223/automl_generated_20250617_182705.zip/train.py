import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from ConfigSpace import Configuration
from typing import Any
import numpy as np
from math import sqrt
import pandas as pd

def train(cfg: Configuration, dataset: Any, seed: int) -> float:
    """
    Trains a CNN model on an image dataset using PyTorch.

    Args:
        cfg (Configuration): Hyperparameter configuration.
        dataset (Any): Dictionary containing 'X' (features) and 'y' (labels).
        seed (int): Random seed for reproducibility.

    Returns:
        float: Negative validation accuracy.
    """
    torch.manual_seed(seed)

    # Extract hyperparameters
    lr = cfg.get('learning_rate')
    batch_size = cfg.get('batch_size')
    optimizer_name = cfg.get('optimizer')
    num_conv_layers = cfg.get('num_conv_layers')
    dropout_rate = cfg.get('dropout_rate')
    num_epochs = cfg.get('num_epochs')
    num_filters_first_layer = cfg.get('num_filters_first_layer')
    use_batch_norm = cfg.get('use_batch_norm')
    
    # Device configuration
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # Data preparation
    X, y = dataset['X'], dataset['y']

    # Reshape and normalize data
    if isinstance(X, pd.DataFrame):
        X = X.values
    if isinstance(y, pd.Series):
        y = y.values

    batch_size = int(batch_size)
    if not isinstance(batch_size, int) or batch_size <= 0:
        raise ValueError(f"batch_size should be a positive integer value, but got batch_size={batch_size}")

    if len(X.shape) == 2:
        n_features = X.shape[1]
        height = width = int(sqrt(n_features))
        if height * height != n_features:
            raise ValueError("Input is not a square image")
        X = X.reshape(-1, 1, height, width)
    elif len(X.shape) == 3:
        X = X.reshape(-1, 1, X.shape[1], X.shape[2])
    elif len(X.shape) == 4:
        pass  # Assuming (N, C, H, W) or (N, H, W, C)
    else:
        raise ValueError("Invalid input shape")

    X = X.astype(np.float32) / 255.0
    y = y.astype(np.int64)

    X = torch.tensor(X, device=device)
    y = torch.tensor(y, device=device)
    
    # Split into training and validation (80/20 split)
    train_size = int(0.8 * len(X))
    X_train, X_val = X[:train_size], X[train_size:]
    y_train, y_val = y[:train_size], y[train_size:]

    train_dataset = torch.utils.data.TensorDataset(X_train, y_train)
    val_dataset = torch.utils.data.TensorDataset(X_val, y_val)
    
    train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    val_loader = torch.utils.data.DataLoader(val_dataset, batch_size=batch_size, shuffle=False)


    # Model definition
    class CNN(nn.Module):
        def __init__(self, num_classes, num_conv_layers, dropout_rate, num_filters_first_layer, use_batch_norm):
            super(CNN, self).__init__()
            self.conv_layers = nn.ModuleList()
            self.batch_norm_layers = nn.ModuleList()  # Batch norm layers list
            
            in_channels = 1  # Assuming grayscale images
            num_filters = num_filters_first_layer

            for i in range(num_conv_layers):
                self.conv_layers.append(nn.Conv2d(in_channels, num_filters, kernel_size=3, padding=1))
                if use_batch_norm:
                    self.batch_norm_layers.append(nn.BatchNorm2d(num_filters))  # Add BatchNorm2d layer
                in_channels = num_filters
                num_filters = min(num_filters * 2, 128)  # Increase filters with each layer, cap at 128

            self.pool = nn.MaxPool2d(2, 2)
            self.dropout = nn.Dropout(dropout_rate)

            # Calculate the size of the flattened layer after convolutions
            self.flattened_size = self._calculate_flattened_size(1, X.shape[2], X.shape[3], use_batch_norm)

            self.fc1 = nn.Linear(self.flattened_size, 128)  # Reduced FC layer size
            self.fc2 = nn.Linear(128, num_classes)

            self.use_batch_norm = use_batch_norm

        def _calculate_flattened_size(self, in_channels, height, width, use_batch_norm):
            # Simulate the convolutional layers to determine the output size
            x = torch.randn(1, in_channels, height, width)
            with torch.no_grad():
                for i, conv in enumerate(self.conv_layers):
                    x = F.relu(conv(x))
                    if use_batch_norm and i < len(self.batch_norm_layers):
                        x = self.batch_norm_layers[i](x)  # Apply batch norm if enabled
                    x = self.pool(x)
            return x.view(1, -1).size(1)

        def forward(self, x):
            for i, conv in enumerate(self.conv_layers):
                x = F.relu(conv(x))
                if self.use_batch_norm and i < len(self.batch_norm_layers):
                    x = self.batch_norm_layers[i](x)  # Apply batch norm if enabled
                x = self.pool(x)
            x = torch.flatten(x, 1)
            x = self.dropout(x)
            x = F.relu(self.fc1(x))
            x = self.fc2(x)
            return x

    model = CNN(len(torch.unique(y)), num_conv_layers, dropout_rate, num_filters_first_layer, use_batch_norm).to(device)


    # Optimizer
    if optimizer_name == "Adam":
        optimizer = optim.Adam(model.parameters(), lr=lr)
    elif optimizer_name == "SGD":
        optimizer = optim.SGD(model.parameters(), lr=lr, momentum=0.9)
    else:
        raise ValueError(f"Unknown optimizer: {optimizer_name}")

    # Loss function
    criterion = nn.CrossEntropyLoss()

    # Training loop
    for epoch in range(num_epochs):
        model.train()
        for batch_idx, (data, target) in enumerate(train_loader):
            optimizer.zero_grad()
            output = model(data)
            loss = criterion(output, target)
            loss.backward()
            optimizer.step()

    # Validation
    model.eval()
    correct = 0
    total = 0
    with torch.no_grad():
        for data, target in val_loader:
            output = model(data)
            _, predicted = torch.max(output.data, 1)
            total += target.size(0)
            correct += (predicted == target).sum().item()

    accuracy = correct / total
    print(f"Validation Accuracy: {accuracy:.4f}")

    return -accuracy
