from ConfigSpace import ConfigurationSpace, UniformFloatHyperparameter, UniformIntegerHyperparameter, CategoricalHyperparameter, InCondition

def get_configspace() -> ConfigurationSpace:
    """
    Defines the configuration space for hyperparameter optimization of a CNN model.

    Returns:
        ConfigurationSpace: The configuration space object.
    """
    cs = ConfigurationSpace()

    # Learning Rate
    learning_rate = UniformFloatHyperparameter(
        "learning_rate",
        lower=1e-4,
        upper=1e-1,
        default_value=1e-3,
        log=True
    )
    cs.add_hyperparameter(learning_rate)

    # Batch Size
    batch_size = CategoricalHyperparameter(
        "batch_size",
        choices=[32, 64, 128, 256],
        default_value=128
    )
    cs.add_hyperparameter(batch_size)

    # Optimizer
    optimizer = CategoricalHyperparameter(
        "optimizer",
        choices=["Adam", "SGD"],
        default_value="Adam"
    )
    cs.add_hyperparameter(optimizer)

    # Number of Convolutional Layers
    num_conv_layers = UniformIntegerHyperparameter(
        "num_conv_layers",
        lower=2,
        upper=5,
        default_value=3
    )
    cs.add_hyperparameter(num_conv_layers)

    # Dropout Rate
    dropout_rate = UniformFloatHyperparameter(
        "dropout_rate",
        lower=0.0,
        upper=0.5,
        default_value=0.2
    )
    cs.add_hyperparameter(dropout_rate)

    # Number of Epochs
    num_epochs = UniformIntegerHyperparameter(
        "num_epochs",
        lower=10,
        upper=50,
        default_value=20
    )
    cs.add_hyperparameter(num_epochs)

    # Number of Filters for the first Conv Layer
    num_filters_first_layer = CategoricalHyperparameter(
        "num_filters_first_layer",
        choices=[16, 32, 64],
        default_value=32
    )
    cs.add_hyperparameter(num_filters_first_layer)

    use_batch_norm = CategoricalHyperparameter(
        "use_batch_norm",
        choices=[True, False],
        default_value=True
    )
    cs.add_hyperparameter(use_batch_norm)

    return cs
