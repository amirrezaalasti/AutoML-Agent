from ConfigSpace import ConfigurationSpace, UniformFloatHyperparameter, UniformIntegerHyperparameter, CategoricalHyperparameter
from ConfigSpace.conditions import EqualsCondition, OrConjunction
from ConfigSpace.hyperparameters import UnParametrizedHyperparameter

def get_configspace() -> ConfigurationSpace:
    """
    Returns a ConfigurationSpace object for hyperparameter optimization of time series models.

    The configuration space includes hyperparameters for model selection (LSTM, GRU, RNN, Linear Regression, or Naive),
    number of layers, number of units per layer, dropout rate, learning rate, batch size,
    and optimization parameters.  Appropriate conditions are added between dependent hyperparameters.
    """
    cs = ConfigurationSpace()

    # Model Type Selection
    model_type = CategoricalHyperparameter(
        "model_type", choices=["LSTM", "GRU", "RNN", "LinearRegression", "Naive"], default_value="LSTM"
    )
    cs.add_hyperparameter(model_type)

    # LSTM/GRU/RNN Specific Hyperparameters
    num_layers = UniformIntegerHyperparameter(
        "num_layers", lower=1, upper=3, default_value=2
    )
    num_units = UniformIntegerHyperparameter(
        "num_units", lower=32, upper=256, default_value=64
    )
    dropout_rate = UniformFloatHyperparameter(
        "dropout_rate", lower=0.0, upper=0.5, default_value=0.2
    )
    cs.add_hyperparameters([num_layers, num_units, dropout_rate])

    # Linear Regression / Naive Baseline does not need layers, units, or dropout
    lstm_condition = EqualsCondition(num_layers, model_type, "LSTM")
    gru_condition = EqualsCondition(num_layers, model_type, "GRU")
    rnn_condition = EqualsCondition(num_layers, model_type, "RNN")
    
    condition_num_layers = OrConjunction(lstm_condition, gru_condition, rnn_condition)
    cs.add_condition(condition_num_layers)

    lstm_condition = EqualsCondition(num_units, model_type, "LSTM")
    gru_condition = EqualsCondition(num_units, model_type, "GRU")
    rnn_condition = EqualsCondition(num_units, model_type, "RNN")

    condition_num_units = OrConjunction(lstm_condition, gru_condition, rnn_condition)
    cs.add_condition(condition_num_units)

    lstm_condition = EqualsCondition(dropout_rate, model_type, "LSTM")
    gru_condition = EqualsCondition(dropout_rate, model_type, "GRU")
    rnn_condition = EqualsCondition(dropout_rate, model_type, "RNN")

    condition_dropout_rate = OrConjunction(lstm_condition, gru_condition, rnn_condition)
    cs.add_condition(condition_dropout_rate)

    # Shared Hyperparameters
    learning_rate = UniformFloatHyperparameter(
        "learning_rate", lower=1e-4, upper=1e-2, default_value=1e-3, log=True
    )
    batch_size = CategoricalHyperparameter(
        "batch_size", choices=[32, 64, 128, 256], default_value=64
    )
    optimizer = CategoricalHyperparameter(
        "optimizer", choices=["Adam", "SGD"], default_value="Adam"
    )
    cs.add_hyperparameters([learning_rate, batch_size, optimizer])

    # Optimizer-specific hyperparameters
    beta_1 = UniformFloatHyperparameter(
        "beta_1", lower=0.8, upper=0.99, default_value=0.9, log=False
    )
    momentum = UniformFloatHyperparameter(
        "momentum", lower=0.0, upper=0.9, default_value=0.0, log=False
    )
    cs.add_hyperparameters([beta_1, momentum])

    # Condition beta_1 on Adam
    condition_beta_1 = EqualsCondition(beta_1, optimizer, "Adam")
    cs.add_condition(condition_beta_1)

    # Condition momentum on SGD
    condition_momentum = EqualsCondition(momentum, optimizer, "SGD")
    cs.add_condition(condition_momentum)
        
    # Add preprocessing boolean options for scaling, detrending, seasonality
    scaler = CategoricalHyperparameter(
        "scaler", choices=["MinMaxScaler", "StandardScaler", "None"], default_value="StandardScaler"
    )
    detrend = CategoricalHyperparameter(
        "detrend", choices=["Differencing", "Polynomial", "None"], default_value="None"
    )
    seasonality_decomp = CategoricalHyperparameter(
        "seasonality_decomp", choices=["STL", "ETS", "None"], default_value="None"
    )
    cs.add_hyperparameters([scaler, detrend, seasonality_decomp])


    return cs
