import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.preprocessing import MinMaxScaler, StandardScaler
from sklearn.linear_model import LinearRegression
import pandas as pd
import numpy as np
from typing import Any
from ConfigSpace import Configuration
from statsmodels.tsa.seasonal import STL
from statsmodels.tsa.api import ExponentialSmoothing

def train(cfg: Configuration, dataset: Any, seed: int) -> float:
    """
    Trains a time series model based on the provided configuration and dataset.

    Args:
        cfg (Configuration): The configuration object containing hyperparameters.
        dataset (Any): The dataset containing 'X' (features) and 'y' (labels).
        seed (int): The random seed for reproducibility.

    Returns:
        float: The negative validation loss/error.
    """
    torch.manual_seed(seed)
    np.random.seed(seed)

    X = dataset['X']
    y = dataset['y']
    
    # Convert to numpy arrays if they are pandas Series
    if isinstance(X, pd.Series):
        X = X.to_numpy()
    if isinstance(y, pd.Series):
        y = y.to_numpy()

    # Handle different shapes for X
    if X.ndim == 1:
        X = X.reshape(-1, 1)
    
    if y.ndim == 1:
        y = y.reshape(-1, 1)

    # Infer sequence length and feature dimension
    if X.ndim == 3:
        seq_len = X.shape[1]
        num_features = X.shape[2]
    elif X.ndim == 2:
        seq_len = 1
        num_features = X.shape[1]
    else:
        raise ValueError(f"Unexpected input dimension: {X.ndim}.  Expected 2 or 3.")
    
    model_type = cfg.get("model_type")
    
    # Data Preprocessing
    scaler_type = cfg.get("scaler")
    detrend_type = cfg.get("detrend")
    seasonality_decomp_type = cfg.get("seasonality_decomp")

    # Scaling
    if scaler_type == "MinMaxScaler":
        scaler = MinMaxScaler()
        X = scaler.fit_transform(X)
        y = scaler.fit_transform(y)
    elif scaler_type == "StandardScaler":
        scaler = StandardScaler()
        X = scaler.fit_transform(X)
        y = scaler.fit_transform(y)

    # Detrending
    if detrend_type == "Differencing":
        X = np.diff(X, axis=0)
        y = np.diff(y, axis=0)
    elif detrend_type == "Polynomial":
        poly = np.polyfit(np.arange(len(y)), y.flatten(), 1)  # Linear detrending
        trend = np.polyval(poly, np.arange(len(y)))
        y = y - trend.reshape(-1, 1)  # Ensure correct shape

    # Seasonality Decomposition
    if seasonality_decomp_type == "STL":
        stl = STL(y.flatten(), seasonal=13)  # Assuming seasonal period of 13
        res = stl.fit()
        y = res.trend
        X = X[13:]
        y = y[13:]
    elif seasonality_decomp_type == "ETS":
        model_ets = ExponentialSmoothing(y, seasonal_periods=12, seasonal='add').fit()
        y = model_ets.resid

    # Split data into training and validation sets
    train_size = int(len(X) * 0.8)
    X_train, X_val = X[:train_size], X[train_size:]
    y_train, y_val = y[:train_size], y[train_size:]

    # Convert to tensors
    X_train_tensor = torch.tensor(X_train, dtype=torch.float32)
    X_val_tensor = torch.tensor(X_val, dtype=torch.float32)
    y_train_tensor = torch.tensor(y_train, dtype=torch.float32)
    y_val_tensor = torch.tensor(y_val, dtype=torch.float32)

    # Model Definition and Training
    if model_type in ["LSTM", "GRU", "RNN"]:
        if X_train_tensor.ndim != 3 and seq_len > 1:
            X_train_tensor = X_train_tensor.reshape(X_train_tensor.shape[0], seq_len, num_features)
            X_val_tensor = X_val_tensor.reshape(X_val_tensor.shape[0], seq_len, num_features)
        elif X_train_tensor.ndim != 3 and seq_len == 1:
            X_train_tensor = X_train_tensor.reshape(X_train_tensor.shape[0], seq_len, num_features)
            X_val_tensor = X_val_tensor.reshape(X_val_tensor.shape[0], seq_len, num_features)

        num_layers = cfg.get("num_layers")
        num_units = cfg.get("num_units")
        dropout_rate = cfg.get("dropout_rate")
        batch_size = cfg.get("batch_size")
        learning_rate = cfg.get("learning_rate")
        optimizer_name = cfg.get("optimizer")
        
        class RNNModel(nn.Module):
            def __init__(self, input_size, hidden_size, num_layers, dropout, rnn_type):
                super(RNNModel, self).__init__()
                self.rnn_type = rnn_type
                if rnn_type == "LSTM":
                    self.rnn = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True, dropout=dropout)
                elif rnn_type == "GRU":
                    self.rnn = nn.GRU(input_size, hidden_size, num_layers, batch_first=True, dropout=dropout)
                else:  # RNN
                    self.rnn = nn.RNN(input_size, hidden_size, num_layers, batch_first=True, dropout=dropout)
                self.linear = nn.Linear(hidden_size, 1)
            def forward(self, x):
                out, _ = self.rnn(x)
                out = self.linear(out[:, -1, :])  # Only the last time step
                return out

        model = RNNModel(num_features, num_units, num_layers, dropout_rate, model_type)
        
        if optimizer_name == "Adam":
            beta_1 = cfg.get("beta_1")
            optimizer = optim.Adam(model.parameters(), lr=learning_rate, betas=(beta_1, 0.999))
        else:  # SGD
            momentum = cfg.get("momentum")
            optimizer = optim.SGD(model.parameters(), lr=learning_rate, momentum=momentum)
        
        criterion = nn.MSELoss()
        
        for epoch in range(10):
            model.train()
            for i in range(0, len(X_train_tensor), batch_size):
                X_batch = X_train_tensor[i:i + batch_size]
                y_batch = y_train_tensor[i:i + batch_size]

                optimizer.zero_grad()
                outputs = model(X_batch)
                loss = criterion(outputs, y_batch)
                loss.backward()
                optimizer.step()

        model.eval()
        with torch.no_grad():
            val_outputs = model(X_val_tensor)
            val_loss = criterion(val_outputs, y_val_tensor)
        return -val_loss.item()
        
    elif model_type == "LinearRegression":
        model = LinearRegression()
        model.fit(X_train, y_train)
        y_pred = model.predict(X_val)
        mse = np.mean((y_val - y_pred)**2)
        return -mse

    elif model_type == "Naive":
        y_pred = np.roll(y_train, 1)
        y_pred[0] = 0 # first pred is set to zero
        mse = np.mean((y_val[:len(y_pred)] - y_pred[-len(y_val):])**2) #compare the two last points from train and val.
        return -mse

    else:
        raise ValueError(f"Unknown model type: {model_type}")
