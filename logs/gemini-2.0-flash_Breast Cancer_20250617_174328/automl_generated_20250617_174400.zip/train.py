import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import accuracy_score, make_scorer, f1_score
from ConfigSpace import Configuration
from typing import Any
import warnings

def train(cfg: Configuration, dataset: Any, seed: int) -> float:
    """
    Trains a machine learning model based on the provided configuration and dataset.

    Args:
        cfg (Configuration): A ConfigurationSpace object containing the hyperparameters.
        dataset (Any): A dictionary containing the training data ('X' for features, 'y' for labels).
        seed (int): Random seed for reproducibility.

    Returns:
        float: The negative accuracy score on the validation set.
    """
    np.random.seed(seed)

    try:
        X = dataset['X']
        y = dataset['y']

        # Convert to DataFrame for easier preprocessing
        X = pd.DataFrame(X)
        y = pd.Series(y)

        # Identify categorical and numerical features (simplified)
        categorical_features = X.select_dtypes(include=['object', 'category']).columns.tolist()
        numerical_features = X.select_dtypes(include=['number']).columns.tolist()

        # Preprocessing pipelines
        numerical_pipeline = Pipeline([
            ('imputer', SimpleImputer(strategy='mean')),
            ('scaler', StandardScaler())
        ])

        categorical_pipeline = Pipeline([
            ('imputer', SimpleImputer(strategy='most_frequent')),
            ('onehot', OneHotEncoder(handle_unknown='ignore'))
        ])

        # Column Transformer
        preprocessor = ColumnTransformer([
            ('numerical', numerical_pipeline, numerical_features),
            ('categorical', categorical_pipeline, categorical_features)
        ], remainder='passthrough') # or 'drop' if you don't want to keep the rest

        # Split data
        X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=seed, stratify=y)

        X_train = preprocessor.fit_transform(X_train)
        X_val = preprocessor.transform(X_val)

        # Model selection and configuration
        model_type = cfg.get("model_type")

        if model_type == "random_forest":
            model = RandomForestClassifier(
                n_estimators=cfg.get("rf_n_estimators"),
                max_depth=cfg.get("rf_max_depth"),
                min_samples_split=cfg.get("rf_min_samples_split"),
                min_samples_leaf=cfg.get("rf_min_samples_leaf"),
                random_state=seed,
                n_jobs=-1,
                class_weight="balanced",
            )
        elif model_type == "gradient_boosting":
            model = GradientBoostingClassifier(
                n_estimators=cfg.get("gb_n_estimators"),
                learning_rate=cfg.get("gb_learning_rate"),
                max_depth=cfg.get("gb_max_depth"),
                min_samples_split=cfg.get("gb_min_samples_split"),
                min_samples_leaf=cfg.get("gb_min_samples_leaf"),
                random_state=seed,
            )
        else:
            raise ValueError(f"Unknown model type: {model_type}")

        # Train model
        with warnings.catch_warnings():
            warnings.filterwarnings("ignore", category=UserWarning) # Suppress some warnings related to convergence
            model.fit(X_train, y_train)

        # Evaluate model
        y_pred = model.predict(X_val)
        accuracy = accuracy_score(y_val, y_pred)
        print(f"Accuracy: {accuracy}")

        return -accuracy  # Return negative accuracy to be minimized by SMAC

    except Exception as e:
        print(f"Error during training: {e}")
        return -0.0  # Return a very low accuracy if training fails
