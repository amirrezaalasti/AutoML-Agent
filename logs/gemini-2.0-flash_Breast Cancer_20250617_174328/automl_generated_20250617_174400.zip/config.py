from ConfigSpace import ConfigurationSpace, UniformFloatHyperparameter, UniformIntegerHyperparameter, CategoricalHyperparameter
from ConfigSpace.conditions import InCondition

def get_configspace() -> ConfigurationSpace:
    """
    Returns a ConfigurationSpace object for hyperparameter optimization of a machine learning model.
    This configuration space is tailored for categorical datasets with a moderate number of samples (around 500-600)
    and focuses on common hyperparameters for models that handle categorical features well.
    """
    cs = ConfigurationSpace()

    # Define hyperparameters

    # Model type (Random Forest or Gradient Boosting)
    model_type = CategoricalHyperparameter(
        "model_type", choices=["random_forest", "gradient_boosting"], default_value="random_forest"
    )
    cs.add_hyperparameter(model_type)

    # Random Forest hyperparameters
    rf_n_estimators = UniformIntegerHyperparameter(
        "rf_n_estimators", lower=50, upper=200, default_value=100,
    )
    rf_max_depth = UniformIntegerHyperparameter(
        "rf_max_depth", lower=2, upper=10, default_value=5,
    )
    rf_min_samples_split = UniformIntegerHyperparameter(
        "rf_min_samples_split", lower=2, upper=10, default_value=2,
    )
    rf_min_samples_leaf = UniformIntegerHyperparameter(
        "rf_min_samples_leaf", lower=1, upper=5, default_value=1,
    )

    # Gradient Boosting hyperparameters
    gb_n_estimators = UniformIntegerHyperparameter(
        "gb_n_estimators", lower=50, upper=200, default_value=100,
    )
    gb_learning_rate = UniformFloatHyperparameter(
        "gb_learning_rate", lower=1e-4, upper=1e-1, default_value=1e-2, log=True,
    )
    gb_max_depth = UniformIntegerHyperparameter(
        "gb_max_depth", lower=2, upper=10, default_value=3,
    )
    gb_min_samples_split = UniformIntegerHyperparameter(
        "gb_min_samples_split", lower=2, upper=10, default_value=2,
    )
    gb_min_samples_leaf = UniformIntegerHyperparameter(
        "gb_min_samples_leaf", lower=1, upper=5, default_value=1,
    )
    
    # Regularization hyperparameters applicable to both
    l1_ratio = UniformFloatHyperparameter(
        "l1_ratio", lower=0.0, upper=1.0, default_value=0.0,
    )

    # Add hyperparameters to the configuration space
    cs.add_hyperparameters([
        rf_n_estimators, rf_max_depth, rf_min_samples_split, rf_min_samples_leaf,
        gb_n_estimators, gb_learning_rate, gb_max_depth, gb_min_samples_split, gb_min_samples_leaf,
        l1_ratio
    ])

    # Define conditional hyperparameters

    rf_condition = InCondition(child=rf_n_estimators, parent=model_type, values=["random_forest"])
    cs.add_condition(rf_condition)
    rf_condition = InCondition(child=rf_max_depth, parent=model_type, values=["random_forest"])
    cs.add_condition(rf_condition)
    rf_condition = InCondition(child=rf_min_samples_split, parent=model_type, values=["random_forest"])
    cs.add_condition(rf_condition)
    rf_condition = InCondition(child=rf_min_samples_leaf, parent=model_type, values=["random_forest"])
    cs.add_condition(rf_condition)

    gb_condition = InCondition(child=gb_n_estimators, parent=model_type, values=["gradient_boosting"])
    cs.add_condition(gb_condition)
    gb_condition = InCondition(child=gb_learning_rate, parent=model_type, values=["gradient_boosting"])
    cs.add_condition(gb_condition)
    gb_condition = InCondition(child=gb_max_depth, parent=model_type, values=["gradient_boosting"])
    cs.add_condition(gb_condition)
    gb_condition = InCondition(child=gb_min_samples_split, parent=model_type, values=["gradient_boosting"])
    cs.add_condition(gb_condition)
    gb_condition = InCondition(child=gb_min_samples_leaf, parent=model_type, values=["gradient_boosting"])
    cs.add_condition(gb_condition)

    return cs
